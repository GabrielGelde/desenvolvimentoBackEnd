package com.example.microblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroblogApplicationTests {

    @Test
    void contextLoads() {
    }

}
